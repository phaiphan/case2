package View;
import DATA.List.MotorList;
import Entity.Manager;
import Entity.Motor;
import Service.Manager.ManagerService;
import java.util.Scanner;

public class ManagerView {

    private ManagerView(){}
    private static final ManagerView managerView= new ManagerView();
    public ManagerView getManagerView() {
        return managerView;
    }
    public static void displayManager() {
        Scanner scanner= new Scanner(System.in);
        System.out.println(" HELLO BOSS");
        System.out.println("\n 1. Xem danh sách seller");
        System.out.println("2. Xem danh sách khách hàng");
        System.out.println("3. Xem danh sách xe trong cửa hàng");
        System.out.println("4. Xem review của khách hàng");
        System.out.println("5. Xem tài khoản");
        System.out.println("0. Đăng xuất \n ------------");
        System.out.println("\n BOSS CẦN GÌ : ");
        do {
            String choose = scanner.nextLine();
            switch (choose) {
                case "1" :
                    ManagerService.checkListSeller();
                    String stop = scanner.nextLine();
                    break;
                case "2":
                    ManagerService.checkListCustomer();
                    String stop2 = scanner.nextLine();
                    break;
                case "3":
                    for (Motor motor:
                    MotorList.readMotorFromFile()) {
                        System.out.println(motor.toString2());
                    }
                    break;
                case "4":
                    ManagerService.readReview();
                    break;
                case "5":
                    System.out.println("Số tiền trong tài khoản của BOSS là:  "+ Manager.getManager().getTHE_AMOUNT());
                    System.out.println(" Ấn phím bất kỳ để tiếp tục");
                    String stop1= scanner.nextLine();
                    break;
                case "0":
                    return;
                default : System.err.println("\n CHỌN LẠI NÀO BOSS");
            }
        } while (true) ;
    }
}
