package View;

import Entity.Customer;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ReviewofCustomerView {
    private static Scanner scanner= new Scanner(System.in);
    private ReviewofCustomerView(){}
    private static final ReviewofCustomerView reviewofCustomerView=new ReviewofCustomerView();
    public static ReviewofCustomerView getReviewofCustomerView() {return reviewofCustomerView;}
    public static void review(Customer customer){
        try {
            FileWriter fw = new FileWriter("C:\\Users\\Admin\\Desktop\\java\\casestudy2\\src\\DATA\\ReviewFromCustomer.txt",true);
            BufferedWriter bw = new BufferedWriter(fw);
            System.out.println("Ý kiến của bạn: ");
            String review= scanner.nextLine();
            bw.newLine();
            bw.write("Góp ý từ khách hàng có Email: "+ customer.getEmail());
            bw.newLine();
            bw.write(review);
            bw.close();
            fw.close();
            System.out.println("----- Ca?M oN g0'p Í cŨa bạN  :D -----");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
