package View;

import DATA.List.MotorList;
import Entity.Motor;

import javax.sound.midi.Soundbank;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FindMotorBikeView {
    private Scanner scanner=new Scanner(System.in);
    private FindMotorBikeView(){}
    private static FindMotorBikeView findMotorBikeView =new FindMotorBikeView();
    public static FindMotorBikeView getFindView() {return findMotorBikeView;}
    public void displayFindMotorBike() {
        System.out.println("1. Tìm theo tên");
        System.out.println("2. Tìm theo giá");
        System.out.println("3. Tìm theo hãng xe");
        System.out.println("0. Back");
        do {
            System.out.println("-----Lựa chọn của bạn-----");
            String choose= scanner.nextLine();
            switch (choose){
                case "1":
                    display_FindByName();
                    break;
                case "2":
                    display_FindbyPrice();
                    break;
                case "3":
                    display_FindByBrand();
                    break;
                case "0": return;
                default: System.err.println("---Chọn lại----");
            }
        } while (true);
    }
    public void display_FindByName() {
        List<Motor> List_MotorbyName= new ArrayList<>();
        Scanner scanner= new Scanner(System.in);
        System.out.println(" Tên chiếc xe bạn muốn tìm:  ");
        String motor_name = scanner.nextLine();
        for (Motor motor:
        MotorList.readMotorFromFile()) {
            if (motor.name.equals(motor_name)) List_MotorbyName.add(motor);
        }
        System.out.println("Danh sách xe:"+ motor_name);
        for (Motor motor:
             List_MotorbyName) {
            System.out.println(motor.toString2());
        }
        if (List_MotorbyName.size()==0) System.out.println("Không có xe: "+ motor_name+" ở đây!");
        System.out.println(" ----- Ấn phím bất kỳ để trở lại-----");
        String stop = scanner.nextLine();
    }
    public void display_FindbyPrice() {
        List<Motor> List_MotorbyPrince= new ArrayList<>();
        Scanner scanner= new Scanner(System.in);
        System.out.println("Giá tối thiểu: ");
        double min_price = scanner.nextDouble();
        System.out.println("giá tối đa: ");
        double max_price= scanner.nextDouble();
        for (Motor motor:
                MotorList.readMotorFromFile()) {
            if (motor.price>=min_price&&motor.price<=max_price) List_MotorbyPrince.add(motor);
        }
        System.out.println("Danh sách xe có giá từ: "+min_price+" tới "+max_price);
        for (Motor motor:
                List_MotorbyPrince) {
            System.out.println(motor.toString2());
        }
        if (List_MotorbyPrince.size()==0) System.out.println("Không có chiếc xe nào có giá như vậy cả: ");
        System.out.println(" ----- Ấn phím bất kỳ để trở lại-----");
        String stop = scanner.nextLine();
    }
    public void display_FindByBrand() {
        List<Motor> List_MotorbyName= new ArrayList<>();
        Scanner scanner= new Scanner(System.in);
        System.out.println(" Tên hãng xe bạn muốn tìm:  ");
        String motor_name = scanner.nextLine();
        for (Motor motor:
                MotorList.readMotorFromFile()) {
            if (motor.brand.equals(motor_name)) List_MotorbyName.add(motor);
        }
        System.out.println("Danh sách xe theo hãng:"+ motor_name);
        for (Motor motor:
                List_MotorbyName) {
            System.out.println(motor.toString2());
        }
        if (List_MotorbyName.size()==0) System.out.println("Không có xe: "+ motor_name+" ở đây!");
        System.out.println(" ----- Ấn phím bất kỳ để trở lại-----");
        String stop = scanner.nextLine();
    }
}
