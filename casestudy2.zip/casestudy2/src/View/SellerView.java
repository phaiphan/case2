package View;

import DATA.List.MotorList;
import Entity.Motor;
import Entity.Seller;
import Service.Manager.ManagerService;

import java.util.Scanner;

public class SellerView {
    public static void displaySellerView(Seller seller){
        Scanner scanner= new Scanner(System.in);
        String choose=null;
        do {
            System.out.println("      Hello    ---"+ seller.getNAME()+"---");
            System.out.println("1. Xem tài khoản của bạn:  ");
            System.out.println("2. Xem danh sách khách hàng");
            System.out.println("3. Xem danh sách xe ở cửa hàng ");
            System.out.println("4. Xem review ");
            System.out.println("5. Đăng xuất");
            System.out.println("----Chọn----");
            choose=scanner.nextLine();
            switch (choose){
                case "1":
                    System.out.println("Tài khoản của bạn hiện tại là:  "+seller.getTHE_AMOUNT()+ " USD");
                case "2":
                    ManagerService.checkListCustomer();
                    String stop2 = scanner.nextLine();
                    break;
                case "3":
                    for (Motor motor:
                            MotorList.readMotorFromFile()) {
                        System.out.println(motor.toString2());
                    }
                    break;
                case "4":
                    ManagerService.readReview();
                    break;
                case "5":
                        return;
                default:
                    System.err.println("Chọn lại đi bạn!");
            }
        }while (true);
    }
}
