package View;

import java.util.Scanner;

import DATA.List.CustomerList;
import DATA.List.SellerList;
import Entity.Customer;
import Entity.Manager;
import Entity.Seller;
import Service.Seller.SellerService;

import static Service.Customer.CustomerService.checkEmail;
import static Service.Customer.CustomerService.checkpassword;
import static View.CustomerView.displayCustomer;

public class LoginView {
    private LoginView(){}
    private static final LoginView loginView= new LoginView();
    public static LoginView getLoginView() {return loginView;}
    private Scanner scanner= new Scanner(System.in);
    public void DisplayLogin() {
       // String choose = scanner.nextLine();
        boolean Exit= false;
       while (!Exit){
        System.out.println(" Đăng nhập dành cho:  ");
        System.out.println("1. Khách hàng");
        System.out.println("2. Seller");
        System.out.println("3. BOSS");
        System.out.println("0. Trở về màn hình chính cửa hàng");
        System.out.println("---------------------");
        System.out.println("Lựa chọn của bạn");
        String choose= scanner.nextLine();
        switch (choose){
            case "1" :
                getLoginView().displayLoginCustomer();
                break;
            case "2":
                displayLoginSeller();
                break;
            case "3":
                getLoginView().displayLoginManager();
                break;
            case "0":
                return;
            default:
                System.err.println("\n Hãy chọn lại");;
        }
    }
    }
    private void displayLoginCustomer() {
        int check = 0;
        String email;
        String password;
        Customer khachhang = null;
        while (check==0) {
            System.out.println("\nNhập vào Email: ");
            email=scanner.nextLine();
            //System.out.println(CustomerList.CUSTOMER_LIST.toString());

            for(Customer customer: CustomerList.CUSTOMER_LIST) {
                if (checkEmail(customer,email)) {
                    khachhang=customer;
                    check=1;
                    break;
                }
            }
           // System.out.println(CustomerList.CUSTOMER_LIST.toString());
            ;
            if (check==0) System.out.println("\nnhập lại email");
            if (check==1) {
                System.out.println("\nNhập mật khẩu");
                password=scanner.nextLine();
                if (checkpassword(khachhang,password)) {
                    System.out.println("\nĐăng nhập thành công: \n------------------");
                    displayCustomer(khachhang);
                } else System.out.println("\nSai mật khẩu \n------------------------");
            }
        }
    }
    public void displayLoginManager() {
        System.out.println("-----Nhập vào Email-----");
        String email = scanner.nextLine();
        System.out.println("\n -----Nhập mật khẩu-----");
        String password = scanner.nextLine();
        if (email.equals(Manager.getManager().getEmail())&& password.equals(Manager.getManager().getPassword())) {
            ManagerView.displayManager();
        }
        else  {
            System.out.println("------------ \nTài khoản không hợp lệ \n----------------");
            return;
        }
    }
    public void displayLoginSeller() {
        Seller SELLER = null;
        boolean login= false;
        System.out.println("-----Nhập vào Email-----");
        String email = scanner.nextLine();
        System.out.println("\n -----Nhập mật khẩu-----");
        String password = scanner.nextLine();
        if(SellerService.checkLogin(email,password)) {
            System.out.println("Đăng nhập thành công");
            for (Seller seller: SellerList.getSellerList()) {
                if (seller.getEMAIL().equals(email)) {
                    SELLER=seller;
                    break;
                }
            }
            SellerView.displaySellerView(SELLER);
        }
        else System.out.println("Đăng nhập thất bại");
        }
}

