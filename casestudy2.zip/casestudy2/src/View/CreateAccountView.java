package View;

import DATA.List.CustomerList;
import Entity.Customer;
import Service.Customer.CustomerService;
import java.util.Scanner;
public class CreateAccountView {
    public static final String emailRegex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
    public static final String phoneRegex = "^0\\d{9}$";

    private CreateAccountView() {}
    private static final CreateAccountView createAccountView = new CreateAccountView();
    public static   CreateAccountView getCreateAccountView() {return createAccountView;}

    public static void displayCreateAccount() {
        boolean exit= false;
        Scanner scanner= new Scanner(System.in);
        System.out.println("Nhap vao ten cua ban: ");
        String name = scanner.nextLine();
        String Email;
        String phonenumer;

        while (true) {
            try {
                while (true) {
                    System.out.println("\n Nhập vào số điện thoại của bạn ( bắt đầu từ 0 và gôm 10 số) : ");
                    phonenumer = scanner.nextLine();
                    if (phonenumer.matches(phoneRegex)) {
                        break;
                    }else System.out.println("SĐT không hợp lệ, mời nhập lại: ");
                }

                while (true) {
                    System.out.println("\n Nhap vao dia chi Email cua ban: ");
                    Email = scanner.nextLine();
                    if (Email.matches(emailRegex)) {
                        break;
                    }else System.out.println("Email không hợp lệ, mời nhập lại");;
                }

                for (Customer customer : CustomerList.CUSTOMER_LIST) {
                    if (customer.getEmail().equals(Email)  ) {
                        throw new Exception("Lỗi trùng Email");
                    }
                }
                break;
            } catch (Exception e) {
                System.err.println("\n Vui lòng nhập lại Email và phone vì đã bị trùng");
            }
        }
        System.out.println("\n Nhap vao password cua ban: ");
        String password= scanner.nextLine();
        System.out.println("Nạp tiền vào tài khoản của bạn: ");
        double the_amount= scanner.nextDouble();
        CustomerService.add(new Customer(name,phonenumer,Email,password,the_amount));
        CustomerList.ReadCustomerListFromFile();
        //getCustomerList().add(new Customer(name,phonenumer,Email,password));


    }

}
