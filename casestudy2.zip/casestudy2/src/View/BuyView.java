package View;

import DATA.List.MotorList;
import DATA.List.SellerList;
import Entity.Customer;
import Entity.Manager;
import Entity.Motor;
import Entity.Seller;
import Service.Motor.MotorService;
import Service.Customer.CustomerService;

import java.util.Scanner;

import static DATA.List.SellerList.getSellerList;

public class BuyView {
    private static Scanner scanner= new Scanner(System.in);
    public static void displayBuyView(Customer customer){
        Motor motor_working=null;
        String motor_name=null;
        Seller seller_working = null;
        boolean None_Seller= true  ;
        System.out.println("\n Quý khách muốn làm việc với seller nào: ");
        for (Seller seller:
                getSellerList()) {
            System.out.println(seller.toString());;
        }
        System.out.println("Book seller theo ID_Seller ^^ :  ");
        String ID_SELLER= scanner.nextLine();
        for (Seller seller:
        SellerList.getSellerList()) {
            if (seller.getID_SELLER().equals(ID_SELLER)) {
                seller_working = seller;
                None_Seller = false;
                break;
            }
        }
        MotorService.getListMotor();
        try {
            while (true){
                System.out.println("-----Chọn xe quý khách muốn mua (coppy tên xe)------- ");
                motor_name= scanner.nextLine();
               if (MotorService.checkMotorByName(motor_name)) {

                   break;
               }
               else throw new Exception("");
            }
        }  catch (Exception e) {
            System.err.println("Sai tên xe, xin mời nhập lại");
        }

        for (Motor motor:
             MotorList.readMotorFromFile()) {
            if(motor.name.equals(motor_name)) {
                motor_working=motor;
                break;
            }
        }
        if (None_Seller== false) {
            System.out.println(" Seller "+seller_working.getNAME()+" rất cảm ơn bạn đã tin tưởng ^^ ");
            CustomerService.Buy(customer,seller_working, Manager.getManager(),motor_working);
        }

    }
}
