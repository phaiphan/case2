package View;

import DATA.List.MotorList;
import Entity.Motor;

import java.util.Scanner;

import static View.CreateAccountView.getCreateAccountView;
import static View.LoginView.getLoginView;

public class BikeStore {
    public static Scanner scanner = new Scanner(System.in);
    private BikeStore() {
    }
    private static final BikeStore CARSTORE = new BikeStore();
    public static BikeStore getInstance() {
        return CARSTORE;
    }
    public void displayCarStore() {
        String choose;
        boolean exit = false;
        do {
            System.out.println("1. Xem danh sach xe");
            System.out.println("2. Tim xe ");
            System.out.println("3. Login");
            System.out.println("4. Tạo tài khoản");
            System.out.println("5. Dat coc");
            System.out.println("------------------------------------------");
            System.out.println("Ban muon gi");
            choose = scanner.next();
            switch (choose) {
                case "1":
                    System.out.println("-----Danh sách xe hiện có tại cửa hàng-----");
                    for (Motor motor:
                    MotorList.readMotorFromFile()) {
                        System.out.println(motor.toString());
                    }
                    System.out.println("--------------- \n -----ÂN PHÍM BẤT KỲ ĐỂ QUAY VỀ-----");
                    String choose2= scanner.next();
                    break;
                case "2":
                    FindMotorBikeView.getFindView().displayFindMotorBike();
                    break;
                case "3":
                    getLoginView().DisplayLogin();
                    break;
                case "4":
                    getCreateAccountView().displayCreateAccount();
                    break;
                case "5":
                    System.out.println("\n Vui lòng đăng nhập ");
                    getLoginView().DisplayLogin();
                    break;
                case "6":
                    break;

                default:
                    System.err.println("\n chon tu 1 toi 6 di: ");

            }
        }
        while (true);
    }
}
