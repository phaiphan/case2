package View;

import Entity.Customer;

import java.util.Scanner;

import static View.FindMotorBikeView.getFindView;

public class CustomerView {
    private static Customer customerWorking= null;
    private CustomerView() {}
    private static final CustomerView customerView= new CustomerView();
    public static CustomerView getCustomerView(){return customerView;};
    private static Scanner scanner = new Scanner(System.in);
    public static void displayCustomer(Customer customer) {
        CustomerView.customerWorking = customer;
        String choose;
        System.out.println("\n\n Xin chao:   --" + customer.getName() + "--  bạn đang cần gì: \n\n");
        System.out.println("1. Xem danh sách xe");
        System.out.println("2. Xem gói độ xe");
        System.out.println("3. Mua ");
        System.out.println("4. Review ");
        System.out.println("0. Đăng xuất và trở về màn hình đăng nhập");
        System.out.println(" Quy khach can gi  ");
        System.out.println("-----------------------------");
        do {
            choose = scanner.nextLine();
            switch (choose) {
                case "1":
                    getFindView().displayFindMotorBike();
                    break;
                case "2":
                    break;
                case "3":
                    BuyView.displayBuyView(customerWorking);
                    break;
                case "4":
                    ReviewofCustomerView.review(customer);
                    break;
                case "5":
                    break;
                case "0":
                    customerWorking=null;
                    return;
                default:
                    System.err.println("\n chon tu 1 toi 6 di: ");
            }
        } while (true);
    }
    private void xemgoidoxe(){

    }
}
