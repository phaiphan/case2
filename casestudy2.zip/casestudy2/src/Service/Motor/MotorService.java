package Service.Motor;

import DATA.List.MotorList;
import Entity.Motor;

public class MotorService {
    public static void getListMotor() {
        for (Motor motor:
        MotorList.readMotorFromFile()) {
            System.out.println(motor.toString2());
        }
    }
    public static boolean checkMotorByName(String motorName){
        for (Motor motor:
             MotorList.readMotorFromFile()) {
            if (motor.name.equals(motorName)) return true;
        }
        return false;
    }
}
