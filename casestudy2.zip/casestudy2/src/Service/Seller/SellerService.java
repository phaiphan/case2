package Service.Seller;

import DATA.List.SellerList;
import Entity.Seller;

public class SellerService {
    public static boolean checkLogin(String email, String password){
        for (Seller seller:
        SellerList.getSellerList()) {
            if (seller.getEMAIL().equals(email)){
                if (seller.getPASSWORD().equals(password)) return true;
            }
        }
        return false;
    }
}
