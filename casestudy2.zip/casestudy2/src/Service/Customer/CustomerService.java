package Service.Customer;

import DATA.List.CustomerList;
import DATA.List.MotorList;
import Entity.Customer;
import Entity.Manager;
import Entity.Motor;
import Entity.Seller;

public class CustomerService {
    public static boolean checkEmail(Customer customer,String email) {
        if (customer.getEmail().equals(email) ) return true;
        else return false;
    }
    public static boolean checkpassword(Customer customer,String password) {
        if (customer.getPassword().equals(password)) return true;
        else return false;
    }
    public static void   add(Customer customer) {
      //  Danhsachkhachhang.getCustomerList().add(customer);
        CustomerList.writerCustomertoFile(customer);
    }
    public static void Buy(Customer customer, Seller seller, Manager manager, Motor motor){
        if (customer.getTHE_AMOUNT()< motor.price) System.out.println("Bạn không đủ tiền cho chiếc xe này ");
        if (motor.NUMBER_OF_MOTOR==0) System.out.println("Chiếc xe này trong cửa hàng đã hết");
        else {
            customer.setTHE_AMOUNT(customer.getTHE_AMOUNT()- motor.price);
            customer.LIST_MOTOR.add(motor);
            seller.setTHE_AMOUNT(seller.getTHE_AMOUNT()+ motor.price*0.1);
            manager.setTHE_AMOUNT(manager.getTHE_AMOUNT()+ motor.price*0.9);
            if (motor.NUMBER_OF_MOTOR>1) motor.setNUMBER_OF_MOTOR(motor.getNUMBER_OF_MOTOR()-1);
            if (motor.NUMBER_OF_MOTOR==1) MotorList.MOTORBIKE.remove(motor);
        }
    }
    public static void Buy(Customer customer,  Manager manager, Motor motor){
        if (customer.getTHE_AMOUNT()< motor.price) System.out.println("Bạn không đủ tiền cho chiếc xe này ");
        if (motor.NUMBER_OF_MOTOR==0) System.out.println("Chiếc xe này trong cửa hàng đã hết");
        else {
            customer.setTHE_AMOUNT(customer.getTHE_AMOUNT()- motor.price);
            customer.LIST_MOTOR.add(motor);
            manager.setTHE_AMOUNT(manager.getTHE_AMOUNT()+ motor.price);
            if (motor.NUMBER_OF_MOTOR>1) motor.setNUMBER_OF_MOTOR(motor.getNUMBER_OF_MOTOR()-1);
            if (motor.NUMBER_OF_MOTOR==1) MotorList.MOTORBIKE.remove(motor);
        }
    }
}
