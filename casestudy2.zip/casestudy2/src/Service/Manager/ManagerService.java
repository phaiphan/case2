package Service.Manager;

import DATA.List.CustomerList;
import DATA.List.SellerList;
import Entity.Customer;
import Entity.Manager;
import Entity.Seller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ManagerService {
    public static void readReview() {
        try {
            String line = "";
            FileReader fr= new FileReader("C:\\Users\\Admin\\Desktop\\java\\casestudy2\\src\\DATA\\ReviewFromCustomer.txt");
            BufferedReader br = new BufferedReader(fr);
            while (true){
                line=br.readLine();
                if (line==null) break;
                System.out.println(line);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void checkMoney() {
        System.out.println("Số tiền trong tài khoản của BOSS là:  "+ Manager.getManager().getTHE_AMOUNT());
    }

    public static void DeleteSeller() {

    }


    public static void importBike() {

    }


    public static void checkListCustomer() {
        for (Customer customer:
                CustomerList.CUSTOMER_LIST) {
            System.out.println(customer.toString());
        }
    }


    public static void checkListSeller() {
        for (Seller seller:
        SellerList.getSellerList()) {
            System.out.println(seller.toString());
        }
    }


    public void checkMotorBike() {

    }
}
