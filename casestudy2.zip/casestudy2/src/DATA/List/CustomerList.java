package DATA.List;

import Entity.Customer;
import Entity.Motor;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerList {
    public CustomerList() {
    }

    public static List<Customer> CUSTOMER_LIST=new ArrayList<>();
    public static void writerCustomertoFile(Customer customer){
        try {
            FileWriter fw = new FileWriter(new File("C:\\Users\\Admin\\Desktop\\java\\casestudy2\\src\\DATA\\customerList.txt"),true);
            BufferedWriter br=new BufferedWriter(fw);
            br.newLine();
            br.write(customer.toString());
           // br.newLine();
            br.close();
            fw.close();
            System.out.println("đã ghi thành công");
        }catch ( Exception e) {}
    }
    public static List<Customer> ReadCustomerListFromFile()  {
        List<Customer> customers = new ArrayList<>();
        try{
            FileReader fr = new FileReader("C:\\Users\\Admin\\Desktop\\java\\casestudy2\\src\\DATA\\customerList.txt");
            BufferedReader br = new BufferedReader(fr);
            String line= "";
            while (true) {
                line=br.readLine();
                if (line == null) break;
                String txt [] = line.split(";");
                String name = txt[0];
                String phone= txt[1];
                String email = txt[2];
                String password= txt[3];
                double the_amount= Double.parseDouble(txt[4]);
                Customer customer= new Customer(name,phone,email,password,the_amount);
                customers.add(customer);
            }
            br.close();
            fr.close();
        } catch (Exception e){

        }
        return CUSTOMER_LIST=customers;
    }
}
