package DATA.List;

import Entity.Seller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class SellerList {
    private SellerList(){}
    private static List<Seller> SELLER_LIST=new ArrayList<>();
    public static List<Seller> getSellerList(){return SELLER_LIST;}
    static {
        Seller seller1 = new Seller("001","Như","Nhu@gmail.com","nhu123","0912312399","Male",45,10000);
        Seller seller2 = new Seller("002","Ngọc","Ngoc@gmail.com","ngoc123","0812312399","Male",26,20000);
        Seller seller3 = new Seller("003","Nghĩa","Nghia@gmail.com","nghia123","0712312399","Male",24,30000);
        Seller seller4 = new Seller("004","Long","Long@gmail.com","Long123","0612312399","FeMale",20,40000);
        getSellerList().add(seller1);
        getSellerList().add(seller2);
        getSellerList().add(seller3);
        getSellerList().add(seller4);
    }
    public static void writerSellertoFile(Seller seller) {
        try{
            FileWriter fw= new FileWriter("C:\\Users\\Admin\\Desktop\\java\\casestudy2\\src\\DATA\\sellerList.txt");
            BufferedWriter br = new BufferedWriter(fw);
            br.write(seller.toString());
            br.close();
            fw.close();
        }catch (Exception e) {
            System.out.println("...");
        }
    }
    public static List<Seller> readSellerFromFile() {
        try{
            FileReader fr= new FileReader("C:\\Users\\Admin\\Desktop\\java\\casestudy2\\src\\DATA\\sellerList.txt");
            BufferedReader br=new BufferedReader(fr);
            String line = "";
            while (true) {
                line=br.readLine();
                if (line==null) break;
                String txt[] = line.split(";");
                String name = txt[0];
                String sex = txt[1];
                int     age= Integer.parseInt(txt[2]);
                Seller seller= new Seller(name,sex,age);
                getSellerList().add(seller);
            }
        }catch (Exception e) {}
        return getSellerList();
    }
}
