package DATA.List;

import Entity.Motor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class MotorList {
    public static List<Motor> MOTORBIKE= new ArrayList<>();
    public static List<Motor> readMotorFromFile() {
        try {
            FileReader fr = new FileReader("C:\\Users\\Admin\\Desktop\\java\\casestudy2\\src\\DATA\\MotorList.txt");
            BufferedReader br= new BufferedReader(fr);
            String line = "";
            while (true){
                line= br.readLine();
                if(line==null) break;
                String text[] = line.split(";");
                String motor_name= text[0];
                String model = text[1];
                String brand = text[2];
                double price = Double.parseDouble(text[3]);
                int    number= Integer.parseInt(text[4]);
                Motor motor= new Motor(motor_name,model,brand,price,number);
                MOTORBIKE.add(motor);
            }
            br.close();
            fr.close();
        } catch (Exception e) {}
            return MOTORBIKE;
    }
    public static void  writedMotorBikeToFile() { // viet vào file thong qua motorlist
        try {
            FileWriter fw = new FileWriter("C:\\Users\\Admin\\Desktop\\java\\casestudy2\\src\\DATA\\MotorList.txt");
            BufferedWriter br = new BufferedWriter(fw);
            for (Motor motor:
                    MOTORBIKE) {
                br.write(motor.toString());
                br.newLine();
            }
            br.close();
            fw.close();
        }catch (Exception e) {}
    }
}
