package Entity;

import java.util.ArrayList;
import java.util.List;

public class Seller {
    private Double THE_AMOUNT;

    public Double getTHE_AMOUNT() {
        return THE_AMOUNT;
    }

    public void setTHE_AMOUNT(Double THE_AMOUNT) {
        this.THE_AMOUNT = THE_AMOUNT;
    }

    private String ID_SELLER;
    private String NAME;
    private String EMAIL;
    private String PASSWORD;
    private String PHONE_NUMBER;
    private String SEX;
    private int AGE;

    public String getID_SELLER() {
        return ID_SELLER;
    }

    public void setID_SELLER(String ID_SELLER) {
        this.ID_SELLER = ID_SELLER;
    }

    public String getNAME() {
        return NAME;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

    public String getEMAIL() {
        return EMAIL;
    }

    public void setEMAIL(String EMAIL) {
        this.EMAIL = EMAIL;
    }

    public String getPASSWORD() {
        return PASSWORD;
    }

    public void setPASSWORD(String PASSWORD) {
        this.PASSWORD = PASSWORD;
    }

    public String getPHONE_NUMBER() {
        return PHONE_NUMBER;
    }

    public void setPHONE_NUMBER(String PHONE_NUMBER) {
        this.PHONE_NUMBER = PHONE_NUMBER;
    }

    public String getSEX() {
        return SEX;
    }

    public void setSEX(String SEX) {
        this.SEX = SEX;
    }

    public int getAGE() {
        return AGE;
    }

    public void setAGE(int AGE) {
        this.AGE = AGE;
    }

    @Override
    public String toString() {
        return   NAME + ';' +
                 SEX + ';' +
                 AGE + ';'+  ID_SELLER+';'+THE_AMOUNT+';'
                ;
    }

    public Seller(String NAME, String SEX, int AGE) {
        this.NAME = NAME;
        this.SEX = SEX;
        this.AGE = AGE;
    }

    public Seller(String ID_SELLER, String NAME, String EMAIL, String PASSWORD, String PHONE_NUMBER, String SEX, int AGE,double THE_AMOUNT) {
        this.ID_SELLER = ID_SELLER;
        this.NAME = NAME;
        this.EMAIL = EMAIL;
        this.PASSWORD = PASSWORD;
        this.PHONE_NUMBER = PHONE_NUMBER;
        this.SEX = SEX;
        this.AGE = AGE;
        this.THE_AMOUNT=THE_AMOUNT;
    }
    private final List<Customer> LIST_khachang= new ArrayList<>();
    public List<Customer> getLIST_khachang() {
        return LIST_khachang;
    }
}
