package Entity;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    public List<Motor> LIST_MOTOR= new ArrayList<>();
    private Double THE_AMOUNT;
    private String phone;
    private String name;
    private String address;

    public Double getTHE_AMOUNT() {
        return THE_AMOUNT;
    }

    public void setTHE_AMOUNT(Double THE_AMOUNT) {
        this.THE_AMOUNT = THE_AMOUNT;
    }

    private String Email;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    private String password;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    public String getEmail() {
        return Email;
    }
    public void setEmail(String email) {
        Email = email;
    }
    public Customer(String name, String phone, String email ,String password,double THE_AMOUNT) {
        this.name = name;
        this.phone = phone;
        Email = email;
        this.password=password;
        this.THE_AMOUNT=THE_AMOUNT;
    }

    @Override
    public String toString() {
        return  name + ';' +
                phone + ';' +
                Email + ';' +
                password + ';'
                + THE_AMOUNT +";"
                ;
    }
}
