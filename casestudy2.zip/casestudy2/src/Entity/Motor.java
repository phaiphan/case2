package Entity;
// tạo 1 superFactory cho khách hàng có thể tự tạo xe cho mình
public class Motor {

    public int NUMBER_OF_MOTOR;
    public double price;
    public String model;
    public String name;
    public String brand;

    public int getNUMBER_OF_MOTOR() {
        return NUMBER_OF_MOTOR;
    }

    public void setNUMBER_OF_MOTOR(int NUMBER_OF_MOTOR) {
        this.NUMBER_OF_MOTOR = NUMBER_OF_MOTOR;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return name +";"+ model + ';' +  brand + ';' + price ;
    }

    public Motor(String name, String model, String brand, double price,int NUMBER_OF_MOTOR) {
        this.price = price;
        this.model = model;
        this.name = name;
        this.brand = brand;
        this.NUMBER_OF_MOTOR=NUMBER_OF_MOTOR;
    }


    public String toString2() {
        return " Tên: "+ name+", Hãng xe: "+brand+", Dòng xe: "+model+", Có giá theo USD là: "+price +", Số lượng xe còn lại: "+ NUMBER_OF_MOTOR;
    }
}
