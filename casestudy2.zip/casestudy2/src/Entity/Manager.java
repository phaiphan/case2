package Entity;

public class Manager {
    private Double THE_AMOUNT= 300000.0;

    public Double getTHE_AMOUNT() {
        return THE_AMOUNT;
    }

    public void setTHE_AMOUNT(Double THE_AMOUNT) {
        this.THE_AMOUNT = THE_AMOUNT;
    }

    private String phone;
    private String name;
    private String address;
    private String Email;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    private String password;

    private Manager() {
        this.phone = "0394805739";
        this.name = "Phan Phái";
        this.address = "Bình Định";
        Email = "pphp@gmail.com";
        this.password = "phaine";
    }
    private static final Manager MANAGER = new Manager();
    public static Manager getManager() {
        return MANAGER;
    }
}
