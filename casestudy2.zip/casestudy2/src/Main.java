import DATA.List.CustomerList;
import DATA.List.SellerList;
import View.BikeStore;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {


        System.out.println("\n\n +  *************** CHAO MUNG TOI CUA HANG CUA PHAI ***************");
        BikeStore bikeStore = BikeStore.getInstance();
        bikeStore.displayCarStore();
    }
}